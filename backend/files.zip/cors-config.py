# app/__init__.py o config.py
"""
Configuración CORS para permitir cookies desde el frontend Vue
IMPORTANTE: Sin esta configuración, las cookies HttpOnly NO funcionarán
"""

from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager

def create_app():
    app = Flask(__name__)
    
    # ===== CONFIGURACIÓN JWT =====
    app.config['JWT_SECRET_KEY'] = 'tu-clave-secreta-super-segura-cambiala'
    app.config['JWT_TOKEN_LOCATION'] = ['cookies']  # JWT en cookies
    app.config['JWT_COOKIE_HTTPONLY'] = True  # Cookie no accesible desde JS
    app.config['JWT_COOKIE_SECURE'] = False  # True en producción (requiere HTTPS)
    app.config['JWT_COOKIE_SAMESITE'] = 'Lax'  # Protección CSRF
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = 3600  # 1 hora
    app.config['JWT_REFRESH_TOKEN_EXPIRES'] = 2592000  # 30 días
    
    # Inicializar JWT
    jwt = JWTManager(app)
    
    # ===== CONFIGURACIÓN CORS =====
    # IMPORTANTE: supports_credentials=True es OBLIGATORIO para cookies
    CORS(app, 
         origins=[
             'http://localhost:5173',  # Vite dev server
             'http://localhost:3000',  # Vue dev server alternativo
             'http://127.0.0.1:5173',
             'http://127.0.0.1:3000',
         ],
         supports_credentials=True,  # ⬅️ CRÍTICO: permite envío de cookies
         allow_headers=['Content-Type', 'Authorization'],
         methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
    )
    
    # Registrar blueprints
    from app.routes.auth_routes import auth_bp
    from app.routes.producto_routes import producto_bp
    # ... otros blueprints
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(producto_bp, url_prefix='/api/productos')
    
    return app


# ===== ALTERNATIVA: Configuración CORS manual =====
"""
Si flask-cors no funciona bien, puedes usar esta configuración manual:
"""

from flask import Flask, request, make_response

def create_app_manual_cors():
    app = Flask(__name__)
    
    # Configuración JWT (igual que arriba)
    # ...
    
    # CORS manual con decorador
    @app.after_request
    def after_request(response):
        # Obtener el origen de la solicitud
        origin = request.headers.get('Origin')
        
        # Lista de orígenes permitidos
        allowed_origins = [
            'http://localhost:5173',
            'http://localhost:3000',
            'http://127.0.0.1:5173',
            'http://127.0.0.1:3000',
        ]
        
        # Si el origen está en la lista, permitirlo
        if origin in allowed_origins:
            response.headers['Access-Control-Allow-Origin'] = origin
            response.headers['Access-Control-Allow-Credentials'] = 'true'  # ⬅️ CRÍTICO
            response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
            response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
        
        return response
    
    # Manejar preflight requests (OPTIONS)
    @app.before_request
    def handle_preflight():
        if request.method == 'OPTIONS':
            response = make_response('', 200)
            origin = request.headers.get('Origin')
            allowed_origins = [
                'http://localhost:5173',
                'http://localhost:3000',
                'http://127.0.0.1:5173',
                'http://127.0.0.1:3000',
            ]
            if origin in allowed_origins:
                response.headers['Access-Control-Allow-Origin'] = origin
                response.headers['Access-Control-Allow-Credentials'] = 'true'
                response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
                response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
            return response
    
    return app


# ===== VERIFICACIÓN EN DESARROLLO =====
"""
Para verificar que CORS funciona correctamente:

1. Abre las DevTools del navegador (F12)
2. Ve a la pestaña Network
3. Haz login
4. Verifica que la respuesta tenga estos headers:
   
   Access-Control-Allow-Origin: http://localhost:5173
   Access-Control-Allow-Credentials: true
   Set-Cookie: access_token_cookie=...; HttpOnly; SameSite=Lax

5. Verifica que en las siguientes peticiones se envíe:
   
   Cookie: access_token_cookie=...

Si ves estos headers, ¡está funcionando correctamente! ✅
"""


# ===== SOLUCIÓN DE PROBLEMAS =====
"""
PROBLEMA: Las cookies no se están guardando

SOLUCIÓN 1: Verificar que el backend esté en el mismo dominio/puerto
- Frontend: http://localhost:5173
- Backend: http://localhost:5000 ✅ (diferente puerto, mismo dominio)

NO usar:
- Frontend: http://localhost:5173
- Backend: http://127.0.0.1:5000 ❌ (diferente dominio)

SOLUCIÓN 2: Verificar credentials: 'include' en fetch
await fetch('...', {
    credentials: 'include',  // ⬅️ Debe estar en TODAS las peticiones
    ...
})

SOLUCIÓN 3: Verificar JWT_COOKIE_SECURE
- Desarrollo: JWT_COOKIE_SECURE = False
- Producción: JWT_COOKIE_SECURE = True (solo con HTTPS)

SOLUCIÓN 4: Verificar CORS origin exacto
CORS(app, origins=['http://localhost:5173'])  # URL exacta, sin trailing slash
"""


# ===== PRODUCCIÓN =====
"""
En producción con HTTPS:

app.config['JWT_COOKIE_SECURE'] = True  # Cookies solo en HTTPS
app.config['JWT_COOKIE_SAMESITE'] = 'Strict'  # Mayor seguridad

CORS(app,
     origins=['https://tu-dominio.com'],
     supports_credentials=True
)
"""
