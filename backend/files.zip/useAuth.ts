// composables/useAuth.ts
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

// Estado global de autenticación
const usuario = ref<any>(null)
const isAuthenticated = ref(false)

export function useAuth() {
  const router = useRouter()

  // Cargar usuario desde localStorage al iniciar
  const loadUsuario = () => {
    const storedUser = localStorage.getItem('usuario')
    if (storedUser) {
      usuario.value = JSON.parse(storedUser)
      isAuthenticated.value = true
    }
  }

  // Verificar si el usuario está autenticado (validar cookie en el backend)
  const verificarAutenticacion = async () => {
    try {
      const response = await fetch('http://127.0.0.1:5000/api/auth/verify', {
        method: 'GET',
        credentials: 'include', // ⬅️ Importante: enviar cookies
      })

      if (response.ok) {
        const data = await response.json()
        isAuthenticated.value = data.valid
        
        // Si está autenticado pero no hay usuario en localStorage, obtenerlo
        if (data.valid && !usuario.value) {
          await obtenerUsuarioActual()
        }
        
        return data.valid
      } else {
        isAuthenticated.value = false
        usuario.value = null
        localStorage.removeItem('usuario')
        return false
      }
    } catch (error) {
      console.error('Error verificando autenticación:', error)
      isAuthenticated.value = false
      return false
    }
  }

  // Obtener datos del usuario actual
  const obtenerUsuarioActual = async () => {
    try {
      const response = await fetch('http://127.0.0.1:5000/api/auth/me', {
        method: 'GET',
        credentials: 'include',
      })

      if (response.ok) {
        const data = await response.json()
        usuario.value = data.usuario
        localStorage.setItem('usuario', JSON.stringify(data.usuario))
        isAuthenticated.value = true
      }
    } catch (error) {
      console.error('Error obteniendo usuario:', error)
    }
  }

  // Login
  const login = async (username: string, password: string) => {
    const response = await fetch('http://127.0.0.1:5000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
      body: JSON.stringify({ username, password }),
    })

    const data = await response.json()

    if (response.ok) {
      usuario.value = data.usuario
      isAuthenticated.value = true
      localStorage.setItem('usuario', JSON.stringify(data.usuario))
      return { success: true, data }
    } else {
      return { success: false, error: data.error || data.detail || 'Error al iniciar sesión' }
    }
  }

  // Logout
  const logout = async () => {
    try {
      await fetch('http://127.0.0.1:5000/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
      })
    } catch (error) {
      console.error('Error al hacer logout:', error)
    } finally {
      // Limpiar estado local
      usuario.value = null
      isAuthenticated.value = false
      localStorage.removeItem('usuario')
      router.push('/login')
    }
  }

  // Verificar si el usuario tiene un permiso específico
  const tienePermiso = (permiso: string): boolean => {
    if (!usuario.value || !usuario.value.permisos) return false
    return usuario.value.permisos.includes(permiso)
  }

  // Verificar si el usuario tiene un rol específico
  const tieneRol = (rol: string): boolean => {
    if (!usuario.value) return false
    return usuario.value.rol === rol
  }

  // Datos computados
  const nombreCompleto = computed(() => {
    if (!usuario.value) return ''
    return `${usuario.value.nombre} ${usuario.value.apellido}`
  })

  const iniciales = computed(() => {
    if (!usuario.value) return ''
    return `${usuario.value.nombre[0]}${usuario.value.apellido[0]}`.toUpperCase()
  })

  return {
    // Estado
    usuario,
    isAuthenticated,
    nombreCompleto,
    iniciales,
    
    // Métodos
    loadUsuario,
    verificarAutenticacion,
    obtenerUsuarioActual,
    login,
    logout,
    tienePermiso,
    tieneRol,
  }
}
