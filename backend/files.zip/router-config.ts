// router/index.ts
import { createRouter, createWebHistory } from 'vue-router'
import { authMiddleware, guestMiddleware, requirePermission, requireRole } from './middleware/auth'

const routes = [
  // ===== RUTAS PÚBLICAS (sin autenticación) =====
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/Login.vue'),
    beforeEnter: guestMiddleware, // Si ya está autenticado, redirige al dashboard
    meta: {
      title: 'Iniciar Sesión'
    }
  },
  
  // ===== RUTAS PROTEGIDAS (requieren autenticación) =====
  {
    path: '/',
    redirect: '/dashboard'
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: () => import('@/views/Dashboard.vue'),
    beforeEnter: authMiddleware, // ⬅️ Requiere estar autenticado
    meta: {
      title: 'Dashboard'
    }
  },
  
  // ===== PRODUCTOS (requiere permiso 'ver_productos') =====
  {
    path: '/productos',
    name: 'productos',
    component: () => import('@/views/Productos/ListaProductos.vue'),
    beforeEnter: requirePermission('ver_productos'), // ⬅️ Requiere permiso específico
    meta: {
      title: 'Productos'
    }
  },
  {
    path: '/productos/crear',
    name: 'productos-crear',
    component: () => import('@/views/Productos/CrearProducto.vue'),
    beforeEnter: requirePermission('crear_productos'),
    meta: {
      title: 'Crear Producto'
    }
  },
  {
    path: '/productos/:id/editar',
    name: 'productos-editar',
    component: () => import('@/views/Productos/EditarProducto.vue'),
    beforeEnter: requirePermission('editar_productos'),
    meta: {
      title: 'Editar Producto'
    }
  },
  
  // ===== MOVIMIENTOS =====
  {
    path: '/movimientos',
    name: 'movimientos',
    component: () => import('@/views/Movimientos/ListaMovimientos.vue'),
    beforeEnter: requirePermission('ver_movimientos'),
    meta: {
      title: 'Movimientos de Stock'
    }
  },
  {
    path: '/movimientos/crear',
    name: 'movimientos-crear',
    component: () => import('@/views/Movimientos/CrearMovimiento.vue'),
    beforeEnter: requirePermission('crear_movimientos'),
    meta: {
      title: 'Nuevo Movimiento'
    }
  },
  
  // ===== PEDIDOS =====
  {
    path: '/pedidos',
    name: 'pedidos',
    component: () => import('@/views/Pedidos/ListaPedidos.vue'),
    beforeEnter: requirePermission('ver_pedidos'),
    meta: {
      title: 'Pedidos'
    }
  },
  {
    path: '/pedidos/crear',
    name: 'pedidos-crear',
    component: () => import('@/views/Pedidos/CrearPedido.vue'),
    beforeEnter: requirePermission('crear_pedidos'),
    meta: {
      title: 'Nuevo Pedido'
    }
  },
  
  // ===== ADMINISTRACIÓN (solo admin) =====
  {
    path: '/usuarios',
    name: 'usuarios',
    component: () => import('@/views/Admin/Usuarios.vue'),
    beforeEnter: requireRole('admin'), // ⬅️ Solo usuarios con rol 'admin'
    meta: {
      title: 'Gestión de Usuarios'
    }
  },
  {
    path: '/auditoria',
    name: 'auditoria',
    component: () => import('@/views/Admin/Auditoria.vue'),
    beforeEnter: requirePermission('ver_auditoria'),
    meta: {
      title: 'Auditoría'
    }
  },
  
  // ===== PERFIL =====
  {
    path: '/perfil',
    name: 'perfil',
    component: () => import('@/views/Perfil.vue'),
    beforeEnter: authMiddleware,
    meta: {
      title: 'Mi Perfil'
    }
  },
  
  // ===== PÁGINA DE ERROR =====
  {
    path: '/forbidden',
    name: 'forbidden',
    component: () => import('@/views/Forbidden.vue'),
    meta: {
      title: 'Acceso Denegado'
    }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'not-found',
    component: () => import('@/views/NotFound.vue'),
    meta: {
      title: '404 - No encontrado'
    }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// Global navigation guard para actualizar el título de la página
router.beforeEach((to, from, next) => {
  document.title = to.meta.title as string || 'Sistema de Inventario'
  next()
})

export default router
