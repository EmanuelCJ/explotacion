// router/middleware/auth.ts
import { useAuth } from '@/composables/useAuth'

/**
 * Middleware de autenticación
 * Protege rutas que requieren login
 */
export async function authMiddleware(to: any, from: any, next: any) {
  const { verificarAutenticacion } = useAuth()

  // Verificar si el usuario está autenticado
  const isValid = await verificarAutenticacion()

  if (isValid) {
    // Usuario autenticado, permitir acceso
    next()
  } else {
    // No autenticado, redirigir al login
    next({
      name: 'login',
      query: { redirect: to.fullPath } // Guardar ruta destino para redireccionar después del login
    })
  }
}

/**
 * Middleware para verificar permisos
 * @param permiso - Permiso requerido para acceder a la ruta
 */
export function requirePermission(permiso: string) {
  return async (to: any, from: any, next: any) => {
    const { verificarAutenticacion, tienePermiso, usuario } = useAuth()

    // Verificar autenticación
    const isValid = await verificarAutenticacion()

    if (!isValid) {
      return next({
        name: 'login',
        query: { redirect: to.fullPath }
      })
    }

    // Verificar permiso
    if (!tienePermiso(permiso)) {
      console.warn(`Usuario ${usuario.value?.username} no tiene permiso: ${permiso}`)
      return next({
        name: 'forbidden',
        params: { mensaje: `No tienes permiso: ${permiso}` }
      })
    }

    next()
  }
}

/**
 * Middleware para verificar roles
 * @param rol - Rol requerido (admin, maestro, supervisor, usuario)
 */
export function requireRole(rol: string) {
  return async (to: any, from: any, next: any) => {
    const { verificarAutenticacion, tieneRol, usuario } = useAuth()

    const isValid = await verificarAutenticacion()

    if (!isValid) {
      return next({
        name: 'login',
        query: { redirect: to.fullPath }
      })
    }

    if (!tieneRol(rol)) {
      console.warn(`Usuario ${usuario.value?.username} no tiene el rol: ${rol}`)
      return next({
        name: 'forbidden',
        params: { mensaje: `Requiere rol: ${rol}` }
      })
    }

    next()
  }
}

/**
 * Middleware para redirigir al dashboard si ya está autenticado
 * Útil para la página de login
 */
export async function guestMiddleware(to: any, from: any, next: any) {
  const { verificarAutenticacion } = useAuth()

  const isValid = await verificarAutenticacion()

  if (isValid) {
    // Ya está autenticado, redirigir al dashboard
    next({ name: 'dashboard' })
  } else {
    // No autenticado, permitir acceso
    next()
  }
}
