"""
Archivo principal para ejecutar el servidor
Aguas Rionegrinas - Sistema de Inventario
"""

import os
from app import create_app
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Crear aplicación
app = create_app()

if __name__ == '__main__':
    # Configuración
    debug_mode = os.getenv('DEBUG', 'False').lower() == 'true'
    port = int(os.getenv('PORT', 5000))
    # ⬇️ CAMBIADO: usar 127.0.0.1 en desarrollo para evitar problemas con CORS
    # En producción puedes usar 0.0.0.0
    host = os.getenv('HOST', '127.0.0.1')
    
    print("\n" + "="*70)
    print("🌊 AGUAS RIONEGRINAS - SISTEMA DE INVENTARIO")
    print("="*70)
    print(f"\n📍 Servidor: http://{host}:{port}")
    print(f"🔧 Entorno: {os.getenv('FLASK_ENV', 'development')}")
    print(f"🐛 Debug: {debug_mode}")
    print(f"🍪 Cookies: HttpOnly habilitadas")
    print(f"🔒 CORS: {os.getenv('CORS_ORIGINS', 'http://localhost:5173')}")
    print("\n📋 ENDPOINTS DISPONIBLES:\n")
    print("🔐 Autenticación:")
    print("   POST   /api/auth/login          - Iniciar sesión")
    print("   POST   /api/auth/logout         - Cerrar sesión")
    print("   POST   /api/auth/refresh        - Renovar token")
    print("   GET    /api/auth/me             - Usuario actual")
    print("   GET    /api/auth/verify         - Verificar token")
    print("   POST   /api/auth/change-password - Cambiar contraseña")
    print("\n📦 Productos:")
    print("   GET    /api/productos           - Listar productos")
    print("   GET    /api/productos/:id       - Detalle de producto")
    print("   POST   /api/productos           - Crear producto")
    print("   PUT    /api/productos/:id       - Actualizar producto")
    print("   DELETE /api/productos/:id       - Eliminar producto")
    print("   GET    /api/productos/:id/stock - Stock por localidad")
    print("   GET    /api/productos/stock-bajo - Productos con stock bajo")
    print("\n🔄 Movimientos:")
    print("   GET    /api/movimientos         - Listar movimientos")
    print("   POST   /api/movimientos/entrada - Entrada de stock")
    print("   POST   /api/movimientos/salida  - Salida de stock")
    print("   POST   /api/movimientos/transferencia - Transferencia")
    print("\n📤 Envíos:")
    print("   GET    /api/envios              - Listar envíos")
    print("   POST   /api/envios              - Crear envío")
    print("   POST   /api/envios/:id/recibir  - Confirmar recepción")
    print("   POST   /api/envios/:id/cancelar - Cancelar envío")
    print("\n🔍 Auditoría:")
    print("   GET    /api/auditoria/producto/:id - Historial de producto")
    print("\n" + "="*70)
    print("\n⚠️  IMPORTANTE:")
    print("   - Frontend debe usar: http://127.0.0.1:5173 (mismo dominio)")
    print("   - Todas las peticiones deben incluir: credentials: 'include'")
    print("   - Las cookies se establecen automáticamente")
    print("\n" + "="*70 + "\n")
    
    # Ejecutar servidor
    app.run(
        host=host,
        port=port,
        debug=debug_mode,
        # ⬇️ AGREGADO: usar reloader solo en desarrollo
        use_reloader=debug_mode
    )
