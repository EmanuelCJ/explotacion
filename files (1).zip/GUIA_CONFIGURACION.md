# 🔧 GUÍA DE CONFIGURACIÓN - Backend Flask

## 📋 RESUMEN DE CAMBIOS

### ✅ Cambios realizados en tu configuración:

**run.py:**
- ✅ Cambiado `HOST=0.0.0.0` → `HOST=127.0.0.1` en desarrollo
- ✅ Agregada información sobre cookies y CORS
- ✅ Mejorada la salida de endpoints disponibles

**app/__init__.py:**
- ✅ Mejorada configuración CORS con `supports_credentials=True`
- ✅ Agregados handlers de error para JWT más descriptivos
- ✅ Agregado endpoint `/api/test-cors` para verificar configuración
- ✅ Agregada configuración de logging
- ✅ Mejorados mensajes de error

**.env:**
- ✅ Agregadas todas las variables necesarias
- ✅ Documentadas con comentarios explicativos

---

## 🚀 PASOS PARA IMPLEMENTAR

### 1. **Reemplazar archivos**

```bash
# Backup de tus archivos actuales (por si acaso)
cp run.py run.py.backup
cp app/__init__.py app/__init__.py.backup

# Copiar los nuevos archivos
# (usa los archivos que te compartí)
```

### 2. **Actualizar .env**

```bash
# Copiar el ejemplo
cp .env.example .env

# Editar con tus valores reales
nano .env  # o vim, code, etc.
```

**Variables críticas que debes configurar:**

```env
# Base de datos (ajusta según tu BD)
DB_HOST=localhost
DB_NAME=aguas_rionegrinas_db
DB_USER=tu_usuario
DB_PASSWORD=tu_password

# CORS (IMPORTANTE: usar 127.0.0.1 en desarrollo)
CORS_ORIGINS=http://127.0.0.1:5173

# Seguridad (generar claves únicas)
SECRET_KEY=clave-super-segura-unica
JWT_SECRET_KEY=otra-clave-diferente-super-segura
```

### 3. **Generar claves seguras**

```python
# Ejecutar en Python para generar claves:
import secrets
print("SECRET_KEY:", secrets.token_hex(32))
print("JWT_SECRET_KEY:", secrets.token_hex(32))
```

### 4. **Verificar configuración**

```bash
# Ejecutar servidor
python run.py

# Deberías ver:
# 🌊 AGUAS RIONEGRINAS - SISTEMA DE INVENTARIO
# 📍 Servidor: http://127.0.0.1:5000
# 🔒 CORS: http://127.0.0.1:5173
# 🍪 Cookies: HttpOnly habilitadas
```

### 5. **Probar CORS**

```bash
# En otra terminal
curl http://127.0.0.1:5000/api/test-cors

# Deberías ver:
{
  "cors_configured": true,
  "allowed_origins": ["http://127.0.0.1:5173"],
  "cookies_enabled": true
}
```

---

## 🔍 VERIFICACIÓN PASO A PASO

### ✅ Checklist de configuración:

#### Backend:
- [ ] `.env` configurado con variables correctas
- [ ] `CORS_ORIGINS` incluye el origen del frontend
- [ ] `JWT_SECRET_KEY` es diferente a `SECRET_KEY`
- [ ] `HOST=127.0.0.1` en desarrollo
- [ ] Servidor corriendo en `http://127.0.0.1:5000`

#### Frontend:
- [ ] Vite/Vue corriendo en `http://127.0.0.1:5173`
- [ ] Todas las peticiones usan `credentials: 'include'`
- [ ] URL del API: `http://127.0.0.1:5000/api/...`

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### Problema 1: "CORS policy: No 'Access-Control-Allow-Origin'"

**Causa:** El origen del frontend no está en `CORS_ORIGINS`

**Solución:**
```env
# En .env, agregar el origen exacto:
CORS_ORIGINS=http://127.0.0.1:5173
```

**Verificar:**
```bash
# El frontend y backend deben usar el mismo dominio:
# ✅ CORRECTO:
# Frontend: http://127.0.0.1:5173
# Backend:  http://127.0.0.1:5000

# ❌ INCORRECTO:
# Frontend: http://localhost:5173
# Backend:  http://127.0.0.1:5000
```

---

### Problema 2: "Las cookies no se guardan"

**Verificar en DevTools → Network → Response Headers:**

```http
Set-Cookie: access_token_cookie=...; HttpOnly; SameSite=Lax; Path=/
Access-Control-Allow-Credentials: true
Access-Control-Allow-Origin: http://127.0.0.1:5173
```

**Si no ves `Access-Control-Allow-Credentials: true`:**
```python
# En __init__.py, verificar:
CORS(app, supports_credentials=True)  # ⬅️ Debe estar
```

**Si no ves `Set-Cookie`:**
```python
# En auth_routes.py, verificar:
response.set_cookie(
    'access_token_cookie',
    value=access_token,
    httponly=True,
    secure=False,  # False en desarrollo
    samesite='Lax'
)
```

---

### Problema 3: "Token expirado inmediatamente"

**Causa:** Diferencia de zona horaria o configuración incorrecta

**Solución:**
```python
# En __init__.py:
from datetime import timedelta

app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)  # No segundos
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)
```

---

### Problema 4: "401 Unauthorized" en todas las peticiones

**Verificar que la cookie se está enviando:**

DevTools → Network → Request Headers:
```http
Cookie: access_token_cookie=eyJ0eXAiOiJKV1QiLCJhbGc...
```

**Si no se envía:**
```javascript
// Verificar en el frontend:
fetch('http://127.0.0.1:5000/api/productos', {
    credentials: 'include'  // ⬅️ DEBE estar en TODAS las peticiones
})
```

---

### Problema 5: "Error de conexión al servidor"

**Verificar que el servidor está corriendo:**
```bash
# Terminal 1: Backend
python run.py
# Debe mostrar: "Running on http://127.0.0.1:5000"

# Terminal 2: Frontend
npm run dev
# Debe mostrar: "Local: http://127.0.0.1:5173"
```

**Verificar que no hay firewall bloqueando:**
```bash
# Linux/Mac
curl http://127.0.0.1:5000/health

# Windows
Invoke-WebRequest http://127.0.0.1:5000/health
```

---

## 🔒 SEGURIDAD EN PRODUCCIÓN

### Cambios necesarios para producción:

**1. Variables de entorno:**
```env
FLASK_ENV=production
DEBUG=False
HOST=0.0.0.0
JWT_COOKIE_SECURE=True  # Requiere HTTPS
CORS_ORIGINS=https://tu-dominio.com
```

**2. Claves secretas:**
```bash
# Generar nuevas claves únicas
python -c "import secrets; print(secrets.token_hex(32))"
```

**3. Base de datos:**
- Usar PostgreSQL en producción
- Conexión con SSL habilitado
- Credenciales en variables de entorno

**4. HTTPS:**
```python
# En __init__.py:
app.config['JWT_COOKIE_SECURE'] = True  # Solo con HTTPS
app.config['JWT_COOKIE_SAMESITE'] = 'Strict'  # Mayor seguridad
```

**5. Rate Limiting:**
```python
# Agregar flask-limiter
from flask_limiter import Limiter

limiter = Limiter(
    app=app,
    key_func=lambda: request.remote_addr,
    default_limits=["200 per day", "50 per hour"]
)

@app.route('/api/auth/login', methods=['POST'])
@limiter.limit("5 per minute")  # Máximo 5 intentos por minuto
def login():
    ...
```

---

## 📊 ESTRUCTURA FINAL DE ARCHIVOS

```
BACKEND/
├── app/
│   ├── __init__.py          ← Configuración principal
│   ├── routers/
│   │   ├── auth_routers.py
│   │   ├── producto_routers.py
│   │   └── ...
│   ├── services/
│   ├── DAO/
│   ├── middlewares/
│   │   ├── decoradores_auth.py
│   │   ├── auth_validation.py
│   │   └── producto_validation.py
│   └── models/
├── logs/                    ← Se crea automáticamente
│   └── aguas_rionegrinas.log
├── .env                     ← TUS configuraciones (NO subir a git)
├── .env.example             ← Ejemplo (SÍ subir a git)
├── .gitignore
├── run.py                   ← Punto de entrada
├── requirements.txt
└── README.md
```

---

## 🧪 TESTING

### Test manual con cURL:

```bash
# 1. Login
curl -X POST http://127.0.0.1:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"comahue719"}' \
  -c cookies.txt \
  -v

# Verificar en la respuesta:
# < Set-Cookie: access_token_cookie=...

# 2. Acceder a endpoint protegido
curl -X GET http://127.0.0.1:5000/api/productos \
  -b cookies.txt \
  -v

# Verificar en la petición:
# > Cookie: access_token_cookie=...
```

### Test con Postman:

1. POST `http://127.0.0.1:5000/api/auth/login`
2. Postman guardará las cookies automáticamente
3. GET `http://127.0.0.1:5000/api/productos`
4. Las cookies se enviarán automáticamente

---

## 📞 RESUMEN DE ENDPOINTS

### Autenticación:
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `POST /api/auth/refresh` - Renovar token
- `GET /api/auth/me` - Usuario actual
- `GET /api/auth/verify` - Verificar token

### Productos:
- `GET /api/productos` - Listar
- `POST /api/productos` - Crear
- `PUT /api/productos/:id` - Actualizar
- `DELETE /api/productos/:id` - Eliminar

### Utilidad:
- `GET /` - Info de la API
- `GET /health` - Health check
- `GET /api/test-cors` - Test CORS (solo debug)

---

## ✅ CHECKLIST FINAL

Antes de continuar, verifica:

- [ ] `.env` configurado correctamente
- [ ] Backend corriendo en `http://127.0.0.1:5000`
- [ ] Frontend corriendo en `http://127.0.0.1:5173`
- [ ] CORS configurado con el origen correcto
- [ ] `credentials: 'include'` en todas las peticiones del frontend
- [ ] Login funciona y establece cookies
- [ ] Cookies se envían en peticiones subsecuentes
- [ ] Endpoints protegidos funcionan con la cookie

---

**¡Tu configuración está lista! 🎉**

Si todo está correcto, deberías poder:
1. Hacer login desde el frontend
2. Ver las cookies en DevTools → Application → Cookies
3. Acceder a endpoints protegidos automáticamente
