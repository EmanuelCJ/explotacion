"""
Aplicación Flask - Aguas Rionegrinas
Inicialización y registro de routers
"""

from flask import Flask, request, make_response
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from datetime import timedelta
import os
from dotenv import load_dotenv

load_dotenv()

jwt = JWTManager()

def create_app():
    """Factory para crear la aplicación Flask"""
    app = Flask(__name__)
    
    # ========================================
    # CONFIGURACIÓN
    # ========================================
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # ===== CONFIGURACIÓN JWT =====
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key-change-in-production')
    app.config['JWT_TOKEN_LOCATION'] = ['cookies']
    app.config['JWT_COOKIE_HTTPONLY'] = True
    
    # ⬇️ IMPORTANTE: False en desarrollo, True en producción con HTTPS
    app.config['JWT_COOKIE_SECURE'] = os.getenv('FLASK_ENV') == 'production'
    
    app.config['JWT_COOKIE_SAMESITE'] = 'Lax'  # Protección CSRF
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)
    app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)
    
    # ⬇️ CSRF: Desactivado porque usamos SameSite=Lax
    app.config['JWT_COOKIE_CSRF_PROTECT'] = False
    
    # ⬇️ NUEVO: Nombres personalizados de cookies (opcional)
    app.config['JWT_ACCESS_COOKIE_NAME'] = 'access_token_cookie'
    app.config['JWT_REFRESH_COOKIE_NAME'] = 'refresh_token_cookie'
    
    # ⬇️ NUEVO: Path de las cookies
    app.config['JWT_COOKIE_PATH'] = '/'
    
    # ===== CONFIGURACIÓN CORS =====
    # ⬇️ CRÍTICO: Obtener origins del .env
    cors_origins = os.getenv('CORS_ORIGINS', 'http://localhost:5173,http://127.0.0.1:5173')
    app.config['CORS_ORIGINS'] = [origin.strip() for origin in cors_origins.split(',')]
    
    # ========================================
    # EXTENSIONES
    # ========================================
    jwt.init_app(app)
    
    # ⬇️ CONFIGURACIÓN CORS COMPLETA
    CORS(app,
         origins=app.config['CORS_ORIGINS'],
         supports_credentials=True,  # ⬅️ CRÍTICO para cookies
         allow_headers=['Content-Type', 'Authorization'],
         methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
         expose_headers=['Content-Type', 'Authorization'])
    
    # ⬇️ ALTERNATIVA: Si flask-cors da problemas, usar configuración manual
    # @app.after_request
    # def after_request(response):
    #     origin = request.headers.get('Origin')
    #     if origin in app.config['CORS_ORIGINS']:
    #         response.headers['Access-Control-Allow-Origin'] = origin
    #         response.headers['Access-Control-Allow-Credentials'] = 'true'
    #         response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    #         response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    #     return response
    
    # ========================================
    # REGISTRAR BLUEPRINTS/ROUTERS
    # ========================================
    from app.routers.auth_routers import auth_bp
    from app.routers.producto_routers import producto_bp
    from app.routers.movimiento_routers import movimiento_bp
    from app.routers.envio_routers import envio_bp
    
    # ⬇️ NUEVO: Importar otros routers cuando los tengas
    # from app.routers.pedido_routers import pedido_bp
    # from app.routers.auditoria_routers import auditoria_bp
    # from app.routers.usuario_routers import usuario_bp
    
    # Registrar con prefijos
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(producto_bp, url_prefix='/api/productos')
    app.register_blueprint(movimiento_bp, url_prefix='/api/movimientos')
    app.register_blueprint(envio_bp, url_prefix='/api/envios')
    
    # app.register_blueprint(pedido_bp, url_prefix='/api/pedidos')
    # app.register_blueprint(auditoria_bp, url_prefix='/api/auditoria')
    # app.register_blueprint(usuario_bp, url_prefix='/api/usuarios')
    
    # ========================================
    # MANEJADORES DE ERRORES
    # ========================================
    
    @app.errorhandler(404)
    def not_found(error):
        return {
            'error': 'Endpoint no encontrado',
            'path': request.path
        }, 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return {
            'error': 'Error interno del servidor',
            'detail': str(error) if app.debug else 'Error en el servidor'
        }, 500
    
    @app.errorhandler(400)
    def bad_request(error):
        return {
            'error': 'Solicitud incorrecta',
            'detail': str(error)
        }, 400
    
    # ===== JWT ERROR HANDLERS =====
    
    @jwt.unauthorized_loader
    def unauthorized_callback(callback):
        return {
            'error': 'Token no proporcionado',
            'detail': 'Debes iniciar sesión para acceder a este recurso'
        }, 401
    
    @jwt.invalid_token_loader
    def invalid_token_callback(callback):
        return {
            'error': 'Token inválido',
            'detail': 'El token proporcionado no es válido'
        }, 401
    
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return {
            'error': 'Token expirado',
            'detail': 'Tu sesión ha expirado, por favor inicia sesión nuevamente'
        }, 401
    
    @jwt.revoked_token_loader
    def revoked_token_callback(jwt_header, jwt_payload):
        return {
            'error': 'Token revocado',
            'detail': 'Este token ha sido revocado'
        }, 401
    
    # ⬇️ NUEVO: Handler para refresh token
    @jwt.needs_fresh_token_loader
    def token_not_fresh_callback(jwt_header, jwt_payload):
        return {
            'error': 'Token no fresco',
            'detail': 'Se requiere un token recién generado'
        }, 401
    
    # ========================================
    # RUTAS BASE
    # ========================================
    
    @app.route('/')
    def index():
        return {
            'app': 'Aguas Rionegrinas - Sistema de Inventario',
            'version': '1.0.0',
            'status': 'running',
            'endpoints': {
                'auth': '/api/auth',
                'productos': '/api/productos',
                'movimientos': '/api/movimientos',
                'envios': '/api/envios'
            }
        }
    
    @app.route('/health')
    def health():
        """Endpoint de health check para monitoreo"""
        return {
            'status': 'healthy',
            'service': 'aguas-rionegrinas-api',
            'environment': os.getenv('FLASK_ENV', 'development')
        }, 200
    
    # ⬇️ NUEVO: Endpoint para verificar configuración CORS (solo en desarrollo)
    @app.route('/api/test-cors')
    def test_cors():
        if app.debug:
            return {
                'cors_configured': True,
                'allowed_origins': app.config['CORS_ORIGINS'],
                'request_origin': request.headers.get('Origin'),
                'cookies_enabled': app.config['JWT_COOKIE_HTTPONLY']
            }
        return {'error': 'Solo disponible en modo debug'}, 403
    
    # ========================================
    # LOGGING (opcional pero recomendado)
    # ========================================
    if not app.debug:
        import logging
        from logging.handlers import RotatingFileHandler
        
        # Crear carpeta de logs si no existe
        if not os.path.exists('logs'):
            os.mkdir('logs')
        
        # Configurar handler
        file_handler = RotatingFileHandler(
            'logs/aguas_rionegrinas.log',
            maxBytes=10240000,  # 10MB
            backupCount=10
        )
        
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
        ))
        
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
        app.logger.setLevel(logging.INFO)
        app.logger.info('Aguas Rionegrinas API startup')
    
    return app
